﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarSalesman
{
    public class Car
    {
        public string Model { get; set; }
        public Engine MyProperty { get; set; }
        public int Weight { get; set; }
        public string Color { get; set; }

    }
}

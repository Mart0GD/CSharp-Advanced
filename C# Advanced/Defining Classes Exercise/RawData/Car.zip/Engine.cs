﻿namespace RawData
{
    public class Engine
    {
        public int Speed;
        public int Power;

        public Engine(int v1, int v2)
        {
            this.Speed = v1;
            this.Power = v2;
        }

    }
}
﻿
namespace OddLines
{
    public class OddLines
    {
        static void Main()
        {
            string inputFile = @"..\..\..\Files\input.txt";
            string outputFile = @"..\..\..\Files\output.txt";

            WriteOddLines(inputFile, outputFile);

        }

        static void WriteOddLines(string input, string output)
        {
            using (StreamReader reader = new StreamReader(input))
            {
                using (StreamWriter writer = new StreamWriter(output))
                {
                    int row = 0;

                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();

                        if (row++ % 2 == 0)
                        {
                            continue;
                        }

                        writer.WriteLine(line);
                    }

                }
            }
        }
    }
}